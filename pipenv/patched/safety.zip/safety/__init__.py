# -*- coding: utf-8 -*-

__author__ = """pyup.io"""
__email__ = 'support@pyup.io'
__version__ = '1.8.1'
