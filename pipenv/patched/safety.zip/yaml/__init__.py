import sys
if sys.version_info[0] == 3:
    from .yaml3 import *
else:
    from .yaml2 import *