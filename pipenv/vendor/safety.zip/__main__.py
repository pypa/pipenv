from safety.cli import cli

cli(prog_name="safety")