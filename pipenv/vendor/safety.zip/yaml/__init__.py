import sys

if sys.version_info[0] < 3:
    from .yaml import *
else:
    from .yaml3 import *