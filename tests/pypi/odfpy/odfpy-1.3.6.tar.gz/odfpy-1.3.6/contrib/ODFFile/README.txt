ODFFile is a Zope 2.x product that will accept an ODT file, and show it as HTML incl.
images. It can optionally put the standard_html_header and standard_html_footer around the
content.
