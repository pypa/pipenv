__title__ = 'tpfd'
__version__ = '0.2.4'
__build__ = 0x02B
__author__ = 'Erin O\'Connell'
__license__ = 'MIT'
__copyright__ = 'Copyright 2016 Erin O\'Connell'

from .parser import Parser