var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: '0.9.9',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};