pytest_django plugin (EXTERNAL)
==========================================

pytest_django is a plugin for ``pytest`` that provides a set of useful tools for testing Django applications, checkout Ben Firshman's `pytest_django github page`_.

.. _`pytest_django github page`: http://github.com/bfirsh/pytest_django/tree/master

