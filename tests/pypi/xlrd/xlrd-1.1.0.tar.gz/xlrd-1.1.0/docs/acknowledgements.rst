Acknowledgements
================

Development of this package would not have been possible without the document
OpenOffice.org's Documentation of the Microsoft Excel File Format"
("OOo docs" for short).
The latest version is available from OpenOffice.org in
`PDF format`__ and `ODT format`__.
Small portions of the OOo docs are reproduced in this
document. A study of the OOo docs is recommended for those who wish a
deeper understanding of the Excel file layout than the xlrd docs can provide.

__ http://sc.openoffice.org/excelfileformat.pdf

__ http://sc.openoffice.org/excelfileformat.odt

Backporting to Python 2.1 was partially funded by
`Journyx - provider of timesheet and project accounting solutions`__.

__ http://journyx.com/

Provision of formatting information in version 0.6.1 was funded by
`Simplistix Ltd`__.

__ http://www.simplistix.co.uk
