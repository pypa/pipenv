======
parser
======
.. automodule:: dateutil.parser

   .. automethod:: dateutil.parser.parse

   .. autoclass:: dateutil.parser.parserinfo
      :members:
      :undoc-members:

   .. automethod:: dateutil.parser.isoparse
