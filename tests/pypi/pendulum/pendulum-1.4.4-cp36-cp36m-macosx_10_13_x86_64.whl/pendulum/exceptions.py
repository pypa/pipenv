# -*- coding: utf-8 -*-

from .parsing.exceptions import ParserError


class PendulumException(BaseException):

    pass
