# -*- coding: utf-8 -*-


class PendulumException(BaseException):

    pass


class PendulumWarning(Warning):

    pass


class PendulumDeprecationWarning(PendulumWarning):

    pass
