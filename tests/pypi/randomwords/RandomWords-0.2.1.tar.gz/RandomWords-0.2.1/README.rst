RandomWords
===========

.. image:: https://travis-ci.org/tomislater/RandomWords.svg?branch=master
    :target: https://travis-ci.org/tomislater/RandomWords
    :alt: Tests for RandomWords

.. image:: https://coveralls.io/repos/github/tomislater/RandomWords/badge.svg?branch=master
    :target: https://coveralls.io/github/tomislater/RandomWords?branch=master
    :alt: Coverage Status

Overview
--------

RandomWords is a useful package for generate random words, nicks, e-mails and lorem ipsum.

Install
-------

Quick way::

    pip install RandomWords

or::

    git clone https://github.com/tomislater/RandomWords.git
    cd RandomWords
    python setup.py install

How to use
----------

Please see `documentation <https://randomwords.readthedocs.org/en/latest/how_to_use.html>`_
