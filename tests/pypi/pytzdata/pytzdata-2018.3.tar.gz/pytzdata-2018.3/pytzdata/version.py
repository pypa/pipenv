# -*- coding: utf-8 -*-

VERSION = '2018.3'

OLSON_VERSION = '2018c'
