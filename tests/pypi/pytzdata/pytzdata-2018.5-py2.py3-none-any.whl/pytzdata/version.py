# -*- coding: utf-8 -*-

VERSION = '2018.5'

OLSON_VERSION = '2018e'
