# -*- coding: utf-8 -*-

from ._compat import FileNotFoundError


class TimezoneNotFound(FileNotFoundError):

    pass
