__version__ = '2.1'

default_app_config = 'formtools.apps.FormToolsConfig'
