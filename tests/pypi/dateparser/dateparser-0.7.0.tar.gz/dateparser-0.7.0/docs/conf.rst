Configurations
--------------

.. automodule:: dateparser.conf
   :members:
