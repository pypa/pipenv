dateparser.calendars package
============================

Submodules
----------


dateparser.calendars.jalali module
----------------------------------

.. automodule:: dateparser.calendars.jalali
	:members: JalaliParser
	:show-inheritance:


Module contents
---------------
.. automodule:: dateparser.calendars
	:members:
	:show-inheritance:
    
