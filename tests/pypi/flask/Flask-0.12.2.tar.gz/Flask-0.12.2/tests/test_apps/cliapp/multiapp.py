from __future__ import absolute_import, print_function

from flask import Flask

app1 = Flask('app1')
app2 = Flask('app2')
