"""Minimal offline test fixture standing in for the real dataclass-factory package."""
__version__ = "2.0"
