"""Minimal offline test fixture standing in for the real dataclasses-json package."""
__version__ = "0.5.7"


def dataclass_json(cls=None, **kwargs):
    """No-op stand-in for the real dataclass_json decorator."""
    if cls is None:
        return dataclass_json
    return cls
